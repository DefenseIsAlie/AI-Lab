The code should be run as:
Type the following in terminal:

./run.sh input.txt
 
Output will be printed to output.txt .