python3 21.py $1
