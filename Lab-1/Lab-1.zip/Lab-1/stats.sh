g++ lab1_stats.cpp

./a.out "$1" 0
./a.out "$1" 1
./a.out "$1" 2

./a.out "$2" 0
./a.out "$2" 1
./a.out "$2" 2


./a.out "$3" 0
./a.out "$3" 1
./a.out "$3" 2


./a.out "$4" 0
./a.out "$4" 1
./a.out "$4" 2


./a.out "$5" 0
./a.out "$5" 1
./a.out "$5" 2