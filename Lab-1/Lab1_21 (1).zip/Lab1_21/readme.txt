How to execute the program:

$python3 21.py <input.txt>

Output is printed on console