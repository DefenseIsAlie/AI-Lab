To run:
./bin/Desdemona ./<path to bot1.so >./<path to bot2.so >
