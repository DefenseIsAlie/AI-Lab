# How to run file?
python 21.py <path to spambase.data>

# Output
Two tables test_accuracy_table.md and train_accuracy_table.md are created.
